package com.ruangong.controller;

import com.ruangong.pojo.FileStudent;
import com.ruangong.pojo.FileTeam;
import com.ruangong.pojo.Result;
import com.ruangong.service.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.core.io.Resource;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Slf4j
@RestController
public class FileController {

    @Autowired
    private FileService fileService;

    @CrossOrigin(origins = "*")
    @PostMapping("/File")
    public Result file(MultipartFile file) throws Exception {
        log.info("文件上传:{}",file);
        String fileName = file.getOriginalFilename();
        int index = fileName.lastIndexOf(".");
        String extname = fileName.substring(index);
        String newFileName = UUID.randomUUID().toString() + extname;
        String filePath="D:/shiyan/" + newFileName;
        file.transferTo(new File("D:\\shiyan\\"+newFileName));

        FileStudent fileInfo = new FileStudent();
        fileInfo.setFileName(newFileName);
        fileInfo.setFilePath(filePath);
        fileInfo.setFileType(extname);
        fileService.FileInfo(fileInfo);

        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/image")
    public ResponseEntity<String> getImage(@RequestParam Integer id) throws  Exception {
        log.info("根据id来查询头像");
        FileStudent file=fileService.getFileById(id);
        String imageUrl=file.getFilePath();
        return ResponseEntity.ok(imageUrl);
    }


    @CrossOrigin(origins = "*")
    @GetMapping("/getTeam")
    public ResponseEntity<Resource> getFile(@RequestParam int id) throws  Exception {
        log.info("根据提交id来查询提交记录图片或者文件");
        FileStudent file=fileService.getFileById(id);
        String filename=file.getFileName();
        Path filePath= Paths.get("D:/shiyan/"+filename);
        Resource resource = new FileSystemResource(filePath);

        int index = filename.lastIndexOf(".");
        String extname = filename.substring(index);



        if (extname.equals(".txt")) {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename); // 设置文件下载时的文件名
            headers.add(HttpHeaders.CONTENT_TYPE, "text/plain"); // 设置文件类型为纯文本
            // 返回文件的流式响应
            return ResponseEntity.ok().headers(headers).body(resource);
        }
        else {return ResponseEntity.ok()
                .contentType(org.springframework.http.MediaType.IMAGE_JPEG) // 根据图片类型设置MIME类型
                .body(resource);}
    }

}
