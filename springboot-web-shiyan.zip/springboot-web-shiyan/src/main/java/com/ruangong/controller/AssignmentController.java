package com.ruangong.controller;

import com.ruangong.pojo.Assignment;
import com.ruangong.pojo.Result;
import com.ruangong.service.AssignmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
public class AssignmentController {
    @Autowired
    private AssignmentService assignmentService;

    @CrossOrigin(origins = "*")
    @GetMapping("/assignments")
    public Result list() {
        log.info("查询全部作业");
        List<Assignment> assignmentlist=assignmentService.list();
        return Result.success(assignmentlist);
    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/assignments/{id}")
    public Result delete(@PathVariable int id) {
        log.info("根据id来删除作业:{}",id);
        assignmentService.delete(id);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/assignments")
    public Result add(@RequestBody Assignment assignment) {
        log.info("新增作业，不用提供时间会自动生成:{}",assignment);
        assignmentService.add(assignment);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/assignment/{id}")
    public Result getById(@PathVariable int id) {
        log.info("根据教师id查询教师发布的作业:{}",id);
        List<Assignment> assignment=assignmentService.getById(id);
        return Result.success(assignment);
    }

    @CrossOrigin(origins = "*")
    @PutMapping("/assignment")
    public Result update(@RequestBody Assignment assignment) {
        log.info("更新作业，不能更新时间:{}",assignment);
        assignmentService.update(assignment);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/assignments/{sid}")
    public Result getassignmentbysid(@PathVariable int sid) {
        log.info("前端传学生id，通过team表拿到学生对应的教师id，再来查询教师id发布的作业返回");
        List<Assignment> assignment=assignmentService.getTeacherid(sid);
        return Result.success(assignment);
    }

}
