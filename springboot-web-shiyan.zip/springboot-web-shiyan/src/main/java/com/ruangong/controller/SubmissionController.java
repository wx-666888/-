package com.ruangong.controller;

import com.ruangong.pojo.*;
import com.ruangong.service.FileService;
import com.ruangong.service.SubmissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@RestController
public class SubmissionController   {
    @Autowired
    private SubmissionService submissionService;

    @Autowired
    private FileService fileService;

    @CrossOrigin(origins = "*")
    @PostMapping("/submission")
    public Result add(@ModelAttribute Submission1 submission1, @RequestParam("file") MultipartFile file) throws Exception{
        log.info("新增提交记录，不用提供时间会自动生成");
        String fileName = file.getOriginalFilename();
        int index = fileName.lastIndexOf(".");
        String extname = fileName.substring(index);
        String newFileName = UUID.randomUUID().toString() + extname;
        String filePath="D:/zuoye/" + newFileName;
        file.transferTo(new File("D:\\zuoye\\"+newFileName));

        FileAssignment fileInfo = new FileAssignment();
        fileInfo.setFileName(newFileName);
        fileInfo.setFilePath(filePath);
        fileInfo.setFileType(extname);
        fileInfo.setSubmissionId(submission1.getSubmissionId());
        fileInfo.setUserId(submission1.getUserId());
        fileService.FileSub(fileInfo);

        submission1.setFilePath(filePath);
        submissionService.insert(submission1);
        return Result.success();
    }

   @CrossOrigin(origins = "*")
    @GetMapping("/submissions")
    public Result getSubByTidAndAid(@RequestBody TidAid td) {
        log.info("根据教师id和作业id，返回对应学生提交作业id");
        int tid=td.getTid();
        int aid=td.getAid();
        List<Submission> submissions=submissionService.getSubByTidAndAid(tid,aid);
        List<Submission2> submission2s=new ArrayList<>();
        for(Submission submission:submissions){
            String userName=submissionService.getNameById(submission.getUserId());
            Submission2 submission2=new Submission2();

            submission2.setSubmissionId(submission.getSubmissionId());
            submission2.setUserId(submission.getUserId());
            submission2.setAssignmentId(submission.getAssignmentId());
            submission2.setSubmissionTime(submission.getSubmissionTime());
            submission2.setFilePath(submission.getFilePath());
            submission2.setVersion(submission.getVersion());
            submission2.setUserName(userName);

            submission2s.add(submission2);

        }
        return Result.success(submission2s);
    }

    //暂时不用
    @CrossOrigin(origins = "*")
    @GetMapping("/submissionFile")
    public ResponseEntity<List<InputStreamResource>> getFile(@RequestBody TidAid td) {
        log.info("根据教师id和作业id，返回对应学生提交作业id");
        int tid=td.getTid();
        int aid=td.getAid();
        List<Integer> submissions=submissionService.getId(tid,aid);
        List<InputStreamResource> resources = submissions.stream()
                .map(id -> {
                    try {
                        // 获取文件对象
                        FileStudent file = fileService.getFileById(id);
                        String filename = file.getFileName();
                        Path filePath = Paths.get("D:/shiyan/" + filename);

                        // 创建文件流
                        InputStream inputStream = new FileInputStream(filePath.toFile());

                        // 将 InputStream 包装成 InputStreamResource
                        return new InputStreamResource(inputStream);
                    } catch (Exception e) {
                        // 如果有错误，返回 null，后面会被过滤掉
                        return null;
                    }
                })
                .filter(Objects::nonNull)  // 过滤掉 null 值（出错的文件）
                .collect(Collectors.toList());

        return ResponseEntity.ok(resources);
    }

    //暂时不用
    @CrossOrigin(origins = "*")
    @GetMapping("/submission/{id}")
    public Result getById(@PathVariable int id) {
        log.info("根据id来查询提交记录:{}",id);
        Submission submission=submissionService.getById(id);
        return Result.success(submission);
    }

    //暂时不用
    @CrossOrigin(origins = "*")
    @PutMapping("/submission")
    public Result update(@ModelAttribute Submission1 submission1, @RequestParam("file") MultipartFile file) throws Exception {
        log.info("更新提交记录，不能更新时间:{}",submission1);

        String fileName = file.getOriginalFilename();
        int index = fileName.lastIndexOf(".");
        String extname = fileName.substring(index);
        String newFileName = UUID.randomUUID().toString() + extname;
        String filePath="D:/shiyan/" + newFileName;
        file.transferTo(new File("D:\\shiyan\\"+newFileName));

        FileStudent fileInfo = new FileStudent();
        fileInfo.setFileName(newFileName);
        fileInfo.setFilePath(filePath);
        fileInfo.setFileType(extname);
        fileService.FileInfo(fileInfo);
        submission1.setFilePath(filePath);


        submissionService.update(submission1);
        return Result.success();
    }

    //暂时不用
    @CrossOrigin(origins = "*")
    @GetMapping("/submission")
    public Result list() {
        log.info("查询全部提交记录");
        List<Submission> submissionlist=submissionService.list();
        return Result.success(submissionlist);
    }

    //暂时不用
    @CrossOrigin(origins = "*")
    @DeleteMapping("/submission/{id}")
    public Result delete(@PathVariable int id) {
        log.info("根据id来删除提交记录");
        submissionService.delete(id);
        return Result.success();
    }

}
