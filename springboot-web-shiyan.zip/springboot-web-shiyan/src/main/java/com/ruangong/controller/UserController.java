package com.ruangong.controller;

import com.ruangong.pojo.*;
import com.ruangong.service.CourseStudentService;
import com.ruangong.service.FileService;
import com.ruangong.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.UUID;

@Slf4j
@RestController

public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private FileService fileService;

    @Autowired
    private CourseStudentService courseStudentService;

    @CrossOrigin(origins = "*")
    @GetMapping("/user")
    public Result list() {
        log.info("查询全部人员信息");
        List<User> userlist=userService.list();
        return Result.success(userlist);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/teacher/{id}")
    public Result listTeacher(@PathVariable Integer id) {
        log.info("根据教师id来查询对应发布的作业,{}",id);
        List<UT> teacher_a=userService.listTeacher(id);
        return Result.success(teacher_a);
    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/user/{id}")
    public Result delete(@PathVariable Integer id) {
        log.info("根据id来删除人员");
        userService.delete(id);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/user")
    public Result add(@RequestBody User user) {
        log.info("新增人员:{}", user);
        userService.add(user);
//        if ("教师".equals(user.getRole()))
//        {
//            courseStudentService.addCourse(user);
//        }
//        else {
//            courseStudentService.addStudent(user);
//        }
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/user/{id}")
    public Result getById(@PathVariable Integer id) {
        log.info("根据id来查询用户:{}",id);
        User user=userService.getById(id);
        return Result.success(user);
    }
    @CrossOrigin(origins = "*")
    @PutMapping("/user")
    public Result update(@RequestBody User user1) throws Exception {
        log.info("更新用户数据:{}", user1);
        userService.update(user1);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/userImage")
    public Result getUserImage(@ModelAttribute User1 user1, @RequestParam(value = "file", required = false) MultipartFile file) throws Exception {
        log.info("更新用户头像");
        User user=userService.getById(user1.getUserId());
        String fileName = file.getOriginalFilename();
        int index = fileName.lastIndexOf(".");
        String extname = fileName.substring(index);
        String newFileName = UUID.randomUUID().toString() + extname;
        String filePath = "D:/shiyan/" + newFileName;
        file.transferTo(new File("D:\\shiyan\\" + newFileName));

        FileStudent fileInfo = new FileStudent();
        fileInfo.setFileName(newFileName);
        fileInfo.setFilePath(filePath);
        fileInfo.setFileType(extname);
        fileInfo.setUserId(user1.getUserId());
        fileService.FileInfo(fileInfo);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/login")
    public Result login(@RequestBody login login) {
        log.info("登录：前端传送用户名和密码，后端匹配成功返回用户id");
        User user1=userService.loginId(login.getAccount(),login.getPassword());
        if(user1.getUserId()!=null){
            return Result.success(user1);
        }
        else return Result.error("用户名或密码错误");
    }
}
