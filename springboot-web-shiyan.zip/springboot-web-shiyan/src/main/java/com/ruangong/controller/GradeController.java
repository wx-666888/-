package com.ruangong.controller;

import com.ruangong.pojo.Grade;
import com.ruangong.pojo.Grade1;
import com.ruangong.pojo.Result;
import com.ruangong.service.GradeService;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
public class GradeController {
    @Autowired
    private GradeService gradeService;



    @CrossOrigin(origins = "*")
    @GetMapping("/grade")
    public Result list(@RequestParam int tid) {
        log.info("教师查评分");
        List<Grade> gradelist=gradeService.list(tid);
        return Result.success(gradelist);
    }

    @CrossOrigin(origins = "*")
    @DeleteMapping("/grade/{id}")
    public Result delete(@PathVariable int id) {
        log.info("根据id来删除评分");
        gradeService.delete(id);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @PostMapping("/grade")
    public Result insert(@RequestBody Grade grade) {
        log.info("新增评分");
        gradeService.insert(grade);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/grade/{id}")
    public Result getById(@PathVariable int id) {
        log.info("根据id来查询评分:{}",id);
        Grade grade=gradeService.getById(id);
        return Result.success(grade);
    }

    @CrossOrigin(origins = "*")
    @PutMapping("/grade")
    public Result update(@RequestBody Grade grade) {
        log.info("更新评分:{}",grade);
        gradeService.update(grade);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/grades/{sid}")
    public Result getGradesBySid(@PathVariable int sid) {
        log.info("学生查提交评分：前端传送学生id，后端在提交表中查询学生的提交id，再到grade表中查对应的提交评分");
        List<Grade1> grades=gradeService.getGradesBySid(sid);
        return Result.success(grades);
    }
}
