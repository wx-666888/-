package com.ruangong.controller;


import com.ruangong.mapper.UserMapper;
import com.ruangong.pojo.*;
import com.ruangong.service.CourseStudentService;
import com.ruangong.service.FileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Slf4j
@RestController
public class CourseStudentController {

    @Autowired
    private CourseStudentService courseStudentService;

    @Autowired
    private FileService fileService;


    @CrossOrigin(origins = "*")
    @GetMapping("/teams")
    public Result getAll(@RequestParam String tname){
        log.info("教师名字的模糊匹配查询");
        List<Teacher> teachers=courseStudentService.getTs(tname);
        return Result.success(teachers);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/addUser")
    public Result addUser(@RequestBody TnameSid tnamesid) {
        log.info("教师id和学生id来组队");
        Teacher teacher=courseStudentService.addUser(tnamesid);
        return Result.success(teacher);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/teamTid")
    public Result getCourseByTid(@RequestParam Integer tid){
        log.info("根据教师id去查找对应的团队并返回");
        Course1 course=courseStudentService.getCourseByTid(tid);
        return Result.success(course);
    }

    @CrossOrigin(origins = "*")
    @PutMapping("/teamTid")
    public Result updateCourseByTid(@RequestBody Team team){
        log.info("根据教师id去修改对应的团队");
        courseStudentService.updateCourseByTid(team);
        return Result.success();
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/teamSid")
    public Result getTeamBySid(@RequestParam Integer sid){
        log.info("根据学生id查询其所有的团队");
        List<Team1> teams=courseStudentService.getTeamBySid(sid);
        return Result.success(teams);
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/teamStid")
    public Result SgetTeamBytid(@RequestParam Integer tid){
        log.info("学生根据teamid查团队信息");
        Team2 team=courseStudentService.SgetTeamBytid(tid);
        return Result.success(team);
    }


    @CrossOrigin(origins = "*")
    @GetMapping("/getFile")
    public ResponseEntity<Resource> getFile(@RequestParam int id) throws  Exception {
        log.info("根据id来查询团队资源");
        FileTeam file=fileService.getFileTeamByid(id);
        String filename=file.getFileName();
        String createdTime=file.getCreatedTime();
        Path filePath=Paths.get("D:/team/"+filename);
        Resource resource = new FileSystemResource(filePath);
        int index = filename.lastIndexOf(".");
        String extname = filename.substring(index);


        if (extname.equals(".txt")) {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename); // 设置文件下载时的文件名
            headers.add(HttpHeaders.CONTENT_TYPE, "text/plain"); // 设置文件类型为纯文本
            // 返回文件的流式响应
            return ResponseEntity.ok().headers(headers).body(resource);
        }
        else {return ResponseEntity.ok()
                .contentType(org.springframework.http.MediaType.IMAGE_JPEG) // 根据图片类型设置MIME类型
                .body(resource);}
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/getTeamNT")
    public Result getFileNT(@RequestParam int id) throws  Exception {
        log.info("根据id来查询团队资源名字时间");
        FileTeam file=fileService.getFileTeamByid(id);
        String filename=file.getFileName();
        String createdTime=file.getCreatedTime();
        FileResponse fileResponse=new FileResponse(filename,createdTime);
        return Result.success(fileResponse);
    }
}
