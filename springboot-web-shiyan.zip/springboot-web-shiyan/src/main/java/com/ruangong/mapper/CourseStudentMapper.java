package com.ruangong.mapper;

import com.ruangong.pojo.*;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CourseStudentMapper {

    List<Integer> getTidsBySid(int sid);

    List<Integer> getSidsBytid(int tid);

    @Insert("insert into course_student (course_id, student_id,teacher_name) VALUES (#{tid},#{sid},#{tname})")
    void insert(int tid, int sid,String tname);

    @Select("SELECT teacher_id FROM course WHERE teacher_name LIKE CONCAT('%', #{tname}, '%')")
    public Integer getTidByTname(String tname);

    @Select("select teacher_name from course where teacher_id=#{tid}")
    public String getNameByid(Integer tid);

    @Select("SELECT DISTINCT teacher_name FROM course WHERE teacher_name LIKE CONCAT('%', #{tname}, '%')")
    public List<String> getTs(String tname);

    public Course1 getCourseByTid(Integer tid);

    void updateCourseByTid(Team team);

    List<SnSi> getStuBySids(List<Integer> sids);

    List<Team1> getCoursesByTids(List<Integer> tids);

    Team2 SgetTeamBytid(Integer tid);

    @Insert("insert into course(teacher_id, teacher_name) values (#{userId},#{userName})")
    public void addCourse(User user);

    @Insert("insert into student(student_name, student_id) values (#{userId},#{userName})")
    public void addStudent(User user);
}
