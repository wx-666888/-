package com.ruangong.mapper;

import com.ruangong.pojo.*;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {
    @Select("select * from user")
    List<User> list();

    @Delete("delete from user where user_id=#{id}")
    void deleteById(Integer id);

    @Insert("insert into user ( role,password,user_name,signature,hobbies,sex,email,phone,account) VALUES " +
            "(#{role},#{password},#{userName},#{signature},#{hobbies},#{sex},#{email},#{phone},#{account})")
    void insert(User user);

    @Select("select * from user where user_id=#{id} ")
    User getById(Integer id);

    void update(User user1);

    List<UT> listTeacher(Integer id);

    gStu getStudent(Integer id);

    @Select("select * from user where account=#{account} and password=#{password}")
    public User getIdBylogin(String account, String password);

    public Teacher getTByTid(Integer tid);

    public List<Teacher> getTs(String tname);

    @Select("select user_name from user where user_id=#{id}")
    public String getNameById(Integer id);
}
