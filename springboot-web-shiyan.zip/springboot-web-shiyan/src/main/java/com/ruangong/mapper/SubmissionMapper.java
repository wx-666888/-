package com.ruangong.mapper;

import com.ruangong.pojo.Assignment;
import com.ruangong.pojo.Submission;
import com.ruangong.pojo.Submission1;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface SubmissionMapper {
    @Select("Select * from submission")
    List<Submission> list();

    @Delete("delete from submission where submission_id=#{id}")
    void deleteById(int id);

    @Insert("insert into submission (submission_id, user_id, assignment_id, submission_time, file_path, version) " +
            "VALUES (#{submissionId},#{userId},#{assignmentId},#{submissionTime},#{filePath},#{version})")
    void insert(Submission1 submission);

    @Select("select * from submission where submission_id=#{id}")
    Submission getById(int id);

    void update(Submission1 submission1);


    List<Submission> findSubBySidAndAid(List<Integer> sids,Integer aid);

    @Select("select * from submission where user_id=#{sid}")
    List<Submission> getSubidBySid(Integer sid);

    List<Submission> getSubBySids(List<Integer> sids,int aid);

    List<Integer> getIds(List<Integer> sids,int aid);
}
