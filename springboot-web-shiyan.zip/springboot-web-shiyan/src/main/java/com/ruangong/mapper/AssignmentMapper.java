package com.ruangong.mapper;

import com.ruangong.pojo.Assignment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import java.util.List;
@Mapper
public interface AssignmentMapper {
    @Select("select * from assignment")
    List<Assignment> list();

    @Select("select * from assignment where assignment_id=#{aid}")
    Assignment getByAid(int aid);

    @Delete("delete from assignment where assignment_id=#{id}")
    void deleteById(int id);

    @Insert("insert into assignment(assignment_id, title, deadline, attachment_path, created_by,open_at,created_at,description,score_rule,upload_method) " +
            "VALUES (#{assignmentId},#{title},#{deadline},#{attachmentPath},#{createdBy},#{openAt},#{createdAt},#{description},#{scoreRule},#{uploadMethod})")
    void insert(Assignment assignment);

    @Select("select * from assignment where created_by=#{id}")
    List<Assignment>  getById(int id);

    @Select("select * from assignment where created_by=#{id};")
    List<Assignment> getByCreateBy(int id);

    void update(Assignment assignment);

    List<Assignment> getByTids(List<Integer> tids);
}
