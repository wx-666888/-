package com.ruangong.mapper;

import com.ruangong.pojo.FileAssignment;
import com.ruangong.pojo.FileStudent;
import com.ruangong.pojo.FileTeam;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface FileMapper {

    @Insert("insert into file_student(file_name, file_path, file_type,user_id) VALUES (#{fileName},#{filePath},#{fileType},#{userId})")
    void FileInfo(FileStudent fileInfo);

    @Insert("insert into file_assignment(user_id, submission_id, file_name, file_path, file_type) " +
            "VALUES (#{userId},#{submissionId},#{fileName},#{filePath},#{fileType})")
    void FileSub(FileAssignment fileInfo);

    @Select("select * from file_student where user_id=#{id}")
    FileStudent getFileById(Integer id);

    @Select("select * from file_assignment where submission_id=#{sid}")
    FileAssignment getFileBySid(Integer sid);

    @Select("select * from file_team where id=#{id}")
    FileTeam getFileTeamByid(Integer id);
}
