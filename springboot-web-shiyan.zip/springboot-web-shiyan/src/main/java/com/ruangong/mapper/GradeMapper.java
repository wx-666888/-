package com.ruangong.mapper;

import com.ruangong.pojo.Grade;
import com.ruangong.pojo.Grade1;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface GradeMapper {

    @Select("select * from grade where graded_by=#{tid}")
    List<Grade> list(int tid);

    @Delete("delete from grade where grade_id=#{id}")
    void deleteById(int id);

    @Insert("insert into grade (grade_id, submission_id, score, feedback, graded_by, graded_time) " +
            "values (#{gradeId},#{submissionId},#{score},#{feedback},#{gradedBy},#{gradedTime})")
    void insert(Grade grade);

    @Select("select * from grade where grade_id=#{id}")
    Grade getById(int id);

    void update(Grade grade);

    @Select("select * from grade where submission_id=#{id}")
    List<Grade1> getGradeBySubId(int id);
}
