package com.ruangong.service;

import com.ruangong.pojo.*;

import java.util.List;

public interface CourseStudentService {

    Teacher addUser(TnameSid tnamesid);

    List<Teacher> getTs(String tname);

    Course1 getCourseByTid(Integer tid);

    void updateCourseByTid(Team team);

    List<Team1> getTeamBySid(Integer sid);

    Team2 SgetTeamBytid(Integer tid);

    void addCourse(User user);

    void addStudent(User user);
}
