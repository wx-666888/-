package com.ruangong.service;

import com.ruangong.pojo.FileAssignment;
import com.ruangong.pojo.FileStudent;
import com.ruangong.pojo.FileTeam;

public interface FileService {
    void FileInfo(FileStudent fileInfo);

    void FileSub(FileAssignment fileInfo);

    FileStudent getFileById(Integer id);

    FileAssignment getFileBySid(Integer sid);

    FileTeam getFileTeamByid(Integer id);
}
