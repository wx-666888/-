package com.ruangong.service.impl;

import com.ruangong.mapper.FileMapper;
import com.ruangong.mapper.UserMapper;
import com.ruangong.pojo.*;
import com.ruangong.service.FileService;
import com.ruangong.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;



    @Override
    public List<User> list(){
        return userMapper.list();
    }

    @Override
    public void delete(Integer id) {
        userMapper.deleteById(id);
    }

    @Override
    public void add(User user) {
        userMapper.insert(user);
    }

    @Override
    public User getById(Integer id) {
        return userMapper.getById(id);
    }

    @Override
    public void update(User user1)  {
        userMapper.update(user1);
    }

    @Override
    public List<UT> listTeacher(Integer id) {
        return userMapper.listTeacher(id);
    }

    @Override
    public User loginId(String account, String password) {
        User user=userMapper.getIdBylogin(account,password);
        return user;
    }
}
