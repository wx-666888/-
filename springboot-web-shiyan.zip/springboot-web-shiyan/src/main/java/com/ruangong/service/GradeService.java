package com.ruangong.service;

import com.ruangong.pojo.Grade;
import com.ruangong.pojo.Grade1;

import java.util.List;

public interface GradeService {
    List<Grade> list(int tid);

    void delete(int id);

    void insert(Grade grade);

    Grade getById(int id);

    void update(Grade grade);

    List<Grade1> getGradesBySid(int sid);
}
