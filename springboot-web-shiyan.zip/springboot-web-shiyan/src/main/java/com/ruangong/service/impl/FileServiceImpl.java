package com.ruangong.service.impl;

import com.ruangong.mapper.FileMapper;
import com.ruangong.pojo.FileAssignment;
import com.ruangong.pojo.FileStudent;
import com.ruangong.pojo.FileTeam;
import com.ruangong.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FileServiceImpl implements FileService {

    @Autowired
    private FileMapper fileMapper;

    @Override
    public void FileInfo(FileStudent fileInfo){
        fileMapper.FileInfo(fileInfo);
    }

    @Override
    public void FileSub(FileAssignment fileInfo){
        fileMapper.FileSub(fileInfo);
    }

    @Override
    public FileStudent getFileById(Integer id){
        return fileMapper.getFileById(id);
    }

    @Override
    public FileAssignment getFileBySid(Integer sid){
        return fileMapper.getFileBySid(sid);
    }

    @Override
    public FileTeam getFileTeamByid(Integer id){
        return fileMapper.getFileTeamByid(id);
    }
}
