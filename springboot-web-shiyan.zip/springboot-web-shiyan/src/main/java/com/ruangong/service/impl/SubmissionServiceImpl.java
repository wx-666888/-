package com.ruangong.service.impl;

import com.ruangong.mapper.CourseStudentMapper;
import com.ruangong.mapper.SubmissionMapper;
import com.ruangong.mapper.UserMapper;
import com.ruangong.pojo.Submission;
import com.ruangong.pojo.Submission1;
import com.ruangong.service.SubmissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class SubmissionServiceImpl implements SubmissionService {

    @Autowired
    private SubmissionMapper submissionMapper;

    @Autowired
    private CourseStudentMapper courseStudentMapper;
    @Autowired
    private UserMapper userMapper;


    @Override
    public List<Submission> list(){
        return submissionMapper.list();
    }

    @Override
    public void delete(int id){
        submissionMapper.deleteById(id);
    }

    @Override
    public void insert(Submission1 submission){
        submission.setSubmissionTime(LocalDateTime.now());
        submissionMapper.insert(submission);
    }

    @Override
    public Submission getById(int id){
        return submissionMapper.getById(id);
    }

    @Override
    public void update(Submission1 submission1){
        submissionMapper.update(submission1);
    }

    @Override
    public List<Submission> getSubByTidAndAid(int tid,int aid) {
        List<Integer> sids=courseStudentMapper.getSidsBytid(tid);
        List<Submission> submissions=submissionMapper.getSubBySids(sids,aid);
        return submissions;
    }

    @Override
    public List<Integer> getId(int tid,int aid){
        List<Integer> sids=courseStudentMapper.getSidsBytid(tid);
        List<Integer> SudIds=submissionMapper.getIds(sids,aid);
        return SudIds;
    }

    @Override
    public  String getNameById(int id){
        return userMapper.getNameById(id);
    }
}
