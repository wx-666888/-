package com.ruangong.service;

import com.ruangong.pojo.Submission;
import com.ruangong.pojo.Submission1;

import java.util.List;

public interface SubmissionService {
    List<Submission> list();

    void delete(int id);

    void insert(Submission1 submission);

    Submission getById(int id);

    void update(Submission1 submission1);

    List<Submission> getSubByTidAndAid(int tid,int aid);

    List<Integer> getId(int tid,int aid);

    String getNameById(int id);
}
