package com.ruangong.service.impl;

import com.ruangong.mapper.AssignmentMapper;
import com.ruangong.mapper.CourseStudentMapper;
import com.ruangong.pojo.Assignment;
import com.ruangong.service.AssignmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Service
public class AssignmentServiceImpl implements AssignmentService {
    @Autowired
    private AssignmentMapper assignmentMapper;

    @Autowired
    private CourseStudentMapper courseStudentMapper;


    @Override
    public List<Assignment> list(){
        return assignmentMapper.list();
    }

    @Override
    public void delete(int id){
        assignmentMapper.deleteById(id);
    }

    @Override
    public void add(Assignment assignment){
            assignment.setDeadline(new Date());
            assignment.setCreatedAt(new Date());
            assignment.setOpenAt(new Date());
            assignmentMapper.insert(assignment);
    }

    @Override
    public List<Assignment>  getById(int id){
        return assignmentMapper.getById(id);
    }

    @Override
    public void update(Assignment assignment){
        assignmentMapper.update(assignment);
    }

    @Override
    public List<Assignment> getTeacherid(int sid){
        List<Integer> tids=courseStudentMapper.getTidsBySid(sid);
        List<Assignment> assignments=assignmentMapper.getByTids(tids);
        return assignments;
    }
}
