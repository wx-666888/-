package com.ruangong.service.impl;

import com.ruangong.mapper.AssignmentMapper;
import com.ruangong.mapper.GradeMapper;
import com.ruangong.mapper.SubmissionMapper;
import com.ruangong.pojo.Assignment;
import com.ruangong.pojo.Grade;
import com.ruangong.pojo.Grade1;
import com.ruangong.pojo.Submission;
import com.ruangong.service.GradeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class GradeServiceImpl implements GradeService {

    @Autowired
    private GradeMapper gradeMapper;

    @Autowired
    private SubmissionMapper submissionMapper;
    @Autowired
    private AssignmentMapper assignmentMapper;

    @Override
    public List<Grade> list(int tid) {
        return gradeMapper.list(tid);
    }

    @Override
    public void delete(int id) {
        gradeMapper.deleteById(id);
    }

    @Override
    public void insert(Grade grade) {
        grade.setGradedTime(LocalDateTime.now());
        gradeMapper.insert(grade);
    }

    @Override
    public Grade getById(int id) {
        return gradeMapper.getById(id);
    }

    @Override
    public void update(Grade grade) {
        gradeMapper.update(grade);
    }

    @Override
    public List<Grade1> getGradesBySid(int sid) {
        List<Submission> submissions=submissionMapper.getSubidBySid(sid);
        List<Grade1> grades=new ArrayList<>();

        for(Submission submission:submissions){
            List<Grade1> grade=gradeMapper.getGradeBySubId(submission.getSubmissionId());
            grades.addAll(grade);
        }
        for(Grade1 grade1:grades){
            Submission submission=submissionMapper.getById(grade1.getSubmissionId());
            Assignment assignment=assignmentMapper.getByAid(submission.getAssignmentId());
            grade1.setTitle(assignment.getTitle());
        }
        return grades;
    }
}
