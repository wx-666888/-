package com.ruangong.service;

import com.ruangong.pojo.UT;
import com.ruangong.pojo.User;
import com.ruangong.pojo.User1;

import java.util.List;

public interface UserService {

    List<User> list();

    void delete(Integer id);

    void add(User user);

    User getById(Integer id);

    void update(User user1) ;

    List<UT> listTeacher(Integer id);

    User loginId(String account, String password);
}
