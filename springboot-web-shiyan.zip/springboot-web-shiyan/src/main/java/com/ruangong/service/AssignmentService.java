package com.ruangong.service;

import com.ruangong.pojo.Assignment;

import java.util.List;

public interface AssignmentService {
    List<Assignment> list();

    void delete(int id);

    void add(Assignment assignment);

    List<Assignment>  getById(int id);

    void update(Assignment assignment);

    List<Assignment> getTeacherid(int sid);
}
