package com.ruangong.service.impl;

import com.ruangong.mapper.CourseStudentMapper;
import com.ruangong.mapper.UserMapper;
import com.ruangong.pojo.*;
import com.ruangong.service.CourseStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseStudentServiceImpl implements CourseStudentService {

    @Autowired
    private CourseStudentMapper courseStudentMapper;

    @Autowired
    private UserMapper userMapper;

    @Override
    public Teacher addUser(TnameSid tnamesid) {
        String tname = tnamesid.getTname();
        int tid=courseStudentMapper.getTidByTname(tname);
        tname=courseStudentMapper.getNameByid(tid);
        int sid= tnamesid.getSid();
        courseStudentMapper.insert(tid,sid,tname);
        Teacher teacher=userMapper.getTByTid(tid);
        return teacher;
    }

    @Override
    public List<Teacher> getTs(String tname) {
        List<Teacher> teachers=userMapper.getTs(tname);
        return teachers;
    }

    @Override
    public Course1 getCourseByTid(Integer tid) {
        List<Integer> sids=courseStudentMapper.getSidsBytid(tid);
        Course1 course=courseStudentMapper.getCourseByTid(tid);
        List<SnSi> students=courseStudentMapper.getStuBySids(sids);
        course.setStudents(students);
        return course;
    }

    @Override
    public void updateCourseByTid(Team team) {
        courseStudentMapper.updateCourseByTid(team);
    }

    @Override
    public List<Team1> getTeamBySid(Integer sid) {
        List<Integer> tids=courseStudentMapper.getTidsBySid(sid);
        return courseStudentMapper.getCoursesByTids(tids);
    }

    @Override
    public Team2 SgetTeamBytid(Integer tid) {
        return courseStudentMapper.SgetTeamBytid(tid);
    }

    @Override
    public void addCourse(User user) {
        courseStudentMapper.addCourse(user);
    }

    @Override
    public void addStudent(User user) {
        courseStudentMapper.addStudent(user);
    }
}
