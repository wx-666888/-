package com.ruangong;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootWebShiyanApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootWebShiyanApplication.class, args);
    }

}
