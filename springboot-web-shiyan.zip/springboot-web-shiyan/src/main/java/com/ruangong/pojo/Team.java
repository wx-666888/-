package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Team {
    private Integer id;
    private Integer teacherId;
    private String teacherName;
    private String teamDescription;
    private String supervisorDescription;
    private String teamAnnouncement;
    private String teamName;
}
