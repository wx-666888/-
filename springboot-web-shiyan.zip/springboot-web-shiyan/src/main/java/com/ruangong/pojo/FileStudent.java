package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileStudent {
    private Integer id;
    private String fileName;
    private String filePath;
    private String fileType;
    private Integer userId;
}