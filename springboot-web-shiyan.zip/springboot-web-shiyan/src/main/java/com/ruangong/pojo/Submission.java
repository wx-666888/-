package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Submission {
    private Integer submissionId;
    private Integer userId;
    private Integer assignmentId;
    private LocalDateTime submissionTime;
    private String filePath;
    private Integer version;
}
