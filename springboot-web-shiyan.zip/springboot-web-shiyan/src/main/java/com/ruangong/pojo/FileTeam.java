package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileTeam {
    private int id;
    private int userId;
    private String fileName;
    private String filePath;
    private String fileType;
    private String createdTime;
}
