package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Course1 {
    private String teamDescription;
    private String supervisorDescription;
    private String teamAnnouncement;
    private String teamName;
    private List<SnSi> students;
}
