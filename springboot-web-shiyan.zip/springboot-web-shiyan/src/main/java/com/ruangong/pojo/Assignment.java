package com.ruangong.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Assignment {
    private String title;
    private int createdBy;
    private int assignmentId;
    private Date deadline;
    private String attachmentPath;
    private Date openAt;
    private Date createdAt;
    private String description;
    private String scoreRule;
    private String uploadMethod;
}
