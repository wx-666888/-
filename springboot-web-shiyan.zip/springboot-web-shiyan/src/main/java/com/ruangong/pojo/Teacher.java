package com.ruangong.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Teacher {
    private String userName;
    private String sex;
    private String signature;
    private String hobbies;
    private String email;
    private String phone;
}
