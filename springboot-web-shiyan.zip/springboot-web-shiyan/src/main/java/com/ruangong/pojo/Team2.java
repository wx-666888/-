package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Team2 {
    private String teamDescription;
    private String supervisorDescription;
    private String teamAnnouncement;
    private String teamName;
}
