package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Grade1 {
    private Integer gradeId;
    private Integer submissionId;
    private double score;
    private String feedback;
    private Integer gradedBy;
    private LocalDateTime gradedTime;
    private String title;
}
