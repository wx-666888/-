package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FileAssignment {
    private Integer id;
    private Integer userId;
    private Integer submissionId;
    private String fileName;
    private String filePath;
    private String fileType;
}
