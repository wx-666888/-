package com.ruangong.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TA {
    private String title;
    private int createdBy;
    private int assignmentId;
    private Date openAt;
    private Date createdAt;
    private Date deadline;
}
