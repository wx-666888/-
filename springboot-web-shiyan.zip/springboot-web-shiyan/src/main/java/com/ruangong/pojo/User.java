package com.ruangong.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {

    private String role;
    private String password;
    private String userName;
    private Integer userId;
    private String signature;
    private String hobbies;
    private String sex;
    private String email;
    private String phone;
    private String account;
}
